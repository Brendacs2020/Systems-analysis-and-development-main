package Principal;

import javax.swing.JOptionPane;
import model.triangulo;

public class principal {
    public static void main(String[] args) {
        triangulo tril = new triangulo ();
        
        tril.setBase(Double.parseDouble(JOptionPane.showInputDialog("Digite a base do triangulo: ")));
        tril.setAltura(Double.parseDouble(JOptionPane.showInputDialog("Digite a altura do triangulo: ")));

        JOptionPane.showMessageDialog(null, "A área do triângulo é: " + tril.getArea());
               
    }  
}
