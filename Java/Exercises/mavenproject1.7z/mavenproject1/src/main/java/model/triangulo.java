package model;

public class triangulo {
    private double base;
    private double altura;

    public triangulo () {
            this(0,0);
    }
public triangulo(double base, double altura) {
    this.base = base;
    this.altura = altura;
}
public double getBase () {
    return this.base;
}
public void setBase(double base) {
    this.base = base;
}
public double getAltura () {
    return this.altura;
}
public void setAltura(double altura) {
    this.altura = altura;
}
public double getArea() {
    return ((getBase() * getAltura()) /2.0);
}
}